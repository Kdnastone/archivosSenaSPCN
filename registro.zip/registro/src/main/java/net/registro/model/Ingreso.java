package net.registro.model;

public class Ingreso {
	private String grupo;
	private String tipo;
	private String nombre_comun;
	private String genero;
	private String especie;
	
	public String getGrupo() {
		return grupo;
	}
	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String getNombre_comun() {
		return nombre_comun;
	}
	public void setNombre_comun(String nombre_comun) {
		this.nombre_comun = nombre_comun;
	}
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}
	public String getEspecie() {
		return especie;
	}
	public void setEspecie(String especie) {
		this.especie = especie;
	}
	
	
}
